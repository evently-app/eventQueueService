# eventQueueService

To test:
1. Run `npm install`.
2. Set your environment variable EVENTBRITE_API_KEY to your eventbrite api key.
3. Run `npm start`
4. Go to http://localhost:3000/grab_eventbrite/newyorkcity/10 (Pick whichever city or radius you'd like)
